var NPC = require("./NPC.js");


var MeleeEnemy = function(name, pos, lvl, attackStrength, attackSpeed) {
Add.call(name, pos)
       
        this.lvl = lvl;
        this.attackStrength = attackStrength;
        this.attackSpeed = attackSpeed;
    };

Object.assign (MeleeEnemy.prototype, Add.prototype);
 MeleeEnemy.prototype{

 walkForward:function() {
        Add.prototype.super.walkForward(this);
        console.log('--> Argh!');
    },
 walkBack:function () {
        super.walkBack();
        console.log('<--')
    }
};
   



if (module.exports) {
    module.exports = MeleeEnemy;
} else {
    throw new Exception("Use node.js!");
}